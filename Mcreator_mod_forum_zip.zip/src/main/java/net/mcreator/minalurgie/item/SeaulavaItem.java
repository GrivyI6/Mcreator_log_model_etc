package net.mcreator.minalurgie.item;

import net.minecraft.world.item.Item;

public class SeaulavaItem extends Item {
	public SeaulavaItem(Item.Properties properties) {
		super(properties);
	}
}