package net.mcreator.minalurgie.item;

import net.minecraft.world.item.Item;

public class SeaucustomItem extends Item {
	public SeaucustomItem(Item.Properties properties) {
		super(properties);
	}
}