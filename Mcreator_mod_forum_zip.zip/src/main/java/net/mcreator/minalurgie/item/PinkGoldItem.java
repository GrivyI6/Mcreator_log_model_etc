package net.mcreator.minalurgie.item;

import net.minecraft.world.item.Item;

public class PinkGoldItem extends Item {
	public PinkGoldItem(Item.Properties properties) {
		super(properties);
	}
}