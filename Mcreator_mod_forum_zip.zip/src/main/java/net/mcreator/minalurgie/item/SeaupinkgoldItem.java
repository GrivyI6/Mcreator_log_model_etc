package net.mcreator.minalurgie.item;

import net.minecraft.world.item.Item;

public class SeaupinkgoldItem extends Item {
	public SeaupinkgoldItem(Item.Properties properties) {
		super(properties.stacksTo(1));
	}
}