/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minalurgie.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.minalurgie.MinalurgieMod;

@EventBusSubscriber
public class MinalurgieModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MinalurgieMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(MinalurgieModItems.PINK_GOLD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(MinalurgieModBlocks.MODELEHACHE.get().asItem());
			tabData.accept(MinalurgieModBlocks.CHAUDRONDEFONDERIE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(MinalurgieModItems.SEAUPINKGOLD.get());
			tabData.accept(MinalurgieModItems.SEAULAVA.get());
			tabData.accept(MinalurgieModItems.SEAUCUSTOM.get());
		}
	}
}