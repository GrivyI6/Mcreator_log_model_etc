/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minalurgie.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.minalurgie.item.SeaupinkgoldItem;
import net.mcreator.minalurgie.item.SeaulavaItem;
import net.mcreator.minalurgie.item.SeaucustomItem;
import net.mcreator.minalurgie.item.PinkGoldItem;
import net.mcreator.minalurgie.MinalurgieMod;

import java.util.function.Function;

public class MinalurgieModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(MinalurgieMod.MODID);
	public static final DeferredItem<Item> PINK_GOLD;
	public static final DeferredItem<Item> MODELEHACHE;
	public static final DeferredItem<Item> SEAUPINKGOLD;
	public static final DeferredItem<Item> SEAULAVA;
	public static final DeferredItem<Item> PINKGOLDBLOCKANIM;
	public static final DeferredItem<Item> LAVABLOCKANIM;
	public static final DeferredItem<Item> SEAUCUSTOM;
	public static final DeferredItem<Item> CHAUDRONDEFONDERIE;
	static {
		PINK_GOLD = register("pink_gold", PinkGoldItem::new);
		MODELEHACHE = block(MinalurgieModBlocks.MODELEHACHE);
		SEAUPINKGOLD = register("seaupinkgold", SeaupinkgoldItem::new);
		SEAULAVA = register("seaulava", SeaulavaItem::new);
		PINKGOLDBLOCKANIM = block(MinalurgieModBlocks.PINKGOLDBLOCKANIM);
		LAVABLOCKANIM = block(MinalurgieModBlocks.LAVABLOCKANIM);
		SEAUCUSTOM = register("seaucustom", SeaucustomItem::new);
		CHAUDRONDEFONDERIE = block(MinalurgieModBlocks.CHAUDRONDEFONDERIE);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}