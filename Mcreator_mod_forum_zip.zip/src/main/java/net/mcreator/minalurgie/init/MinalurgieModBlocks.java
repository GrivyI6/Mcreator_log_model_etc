/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.minalurgie.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.minalurgie.block.PinkgoldblockanimBlock;
import net.mcreator.minalurgie.block.ModelehacheBlock;
import net.mcreator.minalurgie.block.LavablockanimBlock;
import net.mcreator.minalurgie.block.ChaudrondefonderieBlock;
import net.mcreator.minalurgie.MinalurgieMod;

import java.util.function.Function;

public class MinalurgieModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(MinalurgieMod.MODID);
	public static final DeferredBlock<Block> MODELEHACHE;
	public static final DeferredBlock<Block> PINKGOLDBLOCKANIM;
	public static final DeferredBlock<Block> LAVABLOCKANIM;
	public static final DeferredBlock<Block> CHAUDRONDEFONDERIE;
	static {
		MODELEHACHE = register("modelehache", ModelehacheBlock::new);
		PINKGOLDBLOCKANIM = register("pinkgoldblockanim", PinkgoldblockanimBlock::new);
		LAVABLOCKANIM = register("lavablockanim", LavablockanimBlock::new);
		CHAUDRONDEFONDERIE = register("chaudrondefonderie", ChaudrondefonderieBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}